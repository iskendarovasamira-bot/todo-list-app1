import React, { useState, useEffect } from 'react';
import TodoForm from './components/TodoForm';
import FilterButtons from './components/FilterButtons';
import TodoItem from './components/TodoItem';
import './App.css';

function App() {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState('all');

  // Загрузка из localStorage
  useEffect(() => {
    const savedTodos = localStorage.getItem('todos');
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
  }, []);

  // Сохранение в localStorage
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  // Добавление задачи
  const addTodo = (text) => {
    if (text.trim() !== '') {
      const newTodo = {
        id: Date.now(),
        text: text.trim(),
        completed: false
      };
      setTodos([...todos, newTodo]);
    }
  };

  // Переключение статуса
  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  // Удаление задачи
  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  // Фильтрация
  const filteredTodos = todos.filter(todo => {
    switch (filter) {
      case 'active':
        return !todo.completed;
      case 'completed':
        return todo.completed;
      default:
        return true;
    }
  });

  // Статистика
  const activeTodosCount = todos.filter(todo => !todo.completed).length;
  const completedTodosCount = todos.filter(todo => todo.completed).length;

  return (
    <div className="app">
      <div className="container">
        <header className="header">
          <h1>Todo List</h1>
          <p>Организуйте свои задачи</p>
        </header>

        <div className="todo-card">
          <TodoForm onAdd={addTodo} />
          
          <FilterButtons 
            filter={filter} 
            onFilterChange={setFilter}
            activeCount={activeTodosCount}
            completedCount={completedTodosCount}
          />

          {filteredTodos.length === 0 ? (
            <div className="empty-state">
              <p>
                {filter === 'all' && todos.length === 0 && 'Добавьте первую задачу!'}
                {filter === 'all' && todos.length > 0 && 'Все задачи выполнены! 🎉'}
                {filter === 'active' && 'Нет активных задач'}
                {filter === 'completed' && 'Нет выполненных задач'}
              </p>
            </div>
          ) : (
            <div className="todo-list">
              {filteredTodos.map(todo => (
                <TodoItem
                  key={todo.id}
                  todo={todo}
                  onToggle={toggleTodo}
                  onDelete={deleteTodo}
                />
              ))}
            </div>
          )}

          {todos.length > 0 && (
            <div className="todo-stats">
              <span>Всего: {todos.length}</span>
              <span>Активные: {activeTodosCount}</span>
              <span>Выполненные: {completedTodosCount}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;