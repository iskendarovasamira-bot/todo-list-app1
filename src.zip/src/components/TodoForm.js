import React, { useState } from 'react';

function TodoForm({ onAdd }) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (text.trim() === '') {
      setError('Задача не может быть пустой');
      return;
    }

    onAdd(text);
    setText('');
    setError('');
  };

  const handleChange = (e) => {
    setText(e.target.value);
    if (error) setError('');
  };

  return (
    <form onSubmit={handleSubmit} className="todo-form">
      <div className="input-group">
        <input
          type="text"
          value={text}
          onChange={handleChange}
          placeholder="Что нужно сделать?"
          className={`todo-input ${error ? 'error' : ''}`}
        />
        <button type="submit" className="add-button">
          Добавить
        </button>
      </div>
      {error && <div className="error-message">{error}</div>}
    </form>
  );
}

export default TodoForm;