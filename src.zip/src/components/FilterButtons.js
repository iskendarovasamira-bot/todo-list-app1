import React from 'react';

function FilterButtons({ filter, onFilterChange, activeCount, completedCount }) {
  const filters = [
    { key: 'all', label: 'Все', count: activeCount + completedCount },
    { key: 'active', label: 'Активные', count: activeCount },
    { key: 'completed', label: 'Выполненные', count: completedCount }
  ];

  return (
    <div className="filter-buttons">
      {filters.map(({ key, label, count }) => (
        <button
          key={key}
          className={`filter-button ${filter === key ? 'active' : ''}`}
          onClick={() => onFilterChange(key)}
        >
          {label}
          <span className="count-badge">{count}</span>
        </button>
      ))}
    </div>
  );
}

export default FilterButtons;