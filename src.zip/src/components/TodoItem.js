import React from 'react';

function TodoItem({ todo, onToggle, onDelete }) {
  const handleToggle = () => {
    onToggle(todo.id);
  };

  const handleDelete = () => {
    onDelete(todo.id);
  };

  return (
    <div className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <div className="todo-content">
        <button
          className={`checkbox ${todo.completed ? 'checked' : ''}`}
          onClick={handleToggle}
        >
          {todo.completed && '✓'}
        </button>
        <span className="todo-text">{todo.text}</span>
      </div>

      <button
        className="delete-button"
        onClick={handleDelete}
      >
        ×
      </button>
    </div>
  );
}

export default TodoItem;